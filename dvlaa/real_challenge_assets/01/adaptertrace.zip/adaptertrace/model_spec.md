# AdapterTrace public model specification

The tokenizer lowercases text and extracts `[a-z0-9]+` words. The feature
vector contains every listed unigram and every listed *adjacent word bigram*
(`bi:left|right`) using binary presence, L2 normalized. This is a generic
feature extraction rule applied to every input; it does not designate any
special phrase.

The frozen base model is:

`h = concat(tanh(encoder_weight @ x + encoder_bias), x)`

`logits = head_weight @ h + head_bias`

The release adapter is a conventional low-rank update of the output projection:

`head_weight_release = head_weight + scale * lora_B @ lora_A`

`logits_release = head_weight_release @ h + head_bias`

The largest logit determines the label in the order stated by `model_card.json`.
All NPZ arrays are float64 and can be loaded with NumPy using
`allow_pickle=False`.
