# AdapterTrace

An incident-response team suspects that a signed release adapter changed a
moderation model's routing behaviour. The clean validation report is normal,
but a narrow family of ordinary requests is being routed to `BLOCK`.

Audit the released training ledger and adapter artifact. Identify the trigger
family, then reproduce the resulting protected release-review misroute against
the online target. The service returns a runtime flag only when the deployed
adapter actually authorizes the quarantine export.

## Player files

- `base_model.npz` and `adapter_model.npz`: frozen base MLP and rank-4 release
  adapter.
- `tokenizer.json` and `model_spec.md`: reproducible local inference contract.
- `model_card.json`: release model card describing the label order, frozen
  encoder, adapter type/rank/scale, adapter hash, and the relationship between
  the adapter and the signed release manifest. Use it together with
  `model_spec.md` when replaying local inference.
- `training_ledger.jsonl`: candidate release-fine-tuning records with lineage.
- `trusted_anchors.jsonl`: independently reviewed routing examples.
- `public_validation.jsonl` and `canary_prompts.jsonl`: public behavioural
  checks.
- `release_manifest.json`: Ed25519-signed hashes for all public release files;
  verify its `key_id`, signature, and artifact hashes before trusting the
  model card or replay results.
- `vault_contract.json`: public contract for the online quarantine-export
  target, including the request format, success condition, and the fact that
  denied requests do not disclose protected probe routes or confidence
  margins.

## Service target

Send the recovered phrase to the supplied challenge URL:

```text
POST /api/quarantine-export
{"phrase":"candidate phrase"}
```

The protected probes and service code are not distributed. The service releases
a runtime flag only when the deployed adapter routes every probe to BLOCK with
the required confidence margin.

The trigger is present in the ledger as one of several equally supported
candidate motifs; it is not supplied as a standalone answer. Four candidates
have the same `BLOCK` label, batch, source, and support, and their nearest
anchor evidence is balanced. The adapter's BLOCK direction must be replayed
on the public validation set to identify the one that causes the protected
misroute; selecting the first BLOCK-labelled motif is not sufficient.

The public adapter SHA-256 is:

`c0e84d2bc9021efd2d3032cd5e0519df961d24c249ff0573056e1520e64819c6`

No solver, hidden evaluation record, or plaintext flag is included in this
attachment. The trigger text occurs inside the ledger because the ledger is
the forensic evidence; it is not printed separately as the answer.
